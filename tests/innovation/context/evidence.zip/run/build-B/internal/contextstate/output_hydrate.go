package contextstate

import (
	"context"
	"errors"
	"fmt"

	"aegisrt/internal/domain"
)

type dependencyArtifact struct {
	producerTaskID string
	artifactIndex  int
	record         ArtifactRecord
}

func (r *Repository) hydrateDependenciesLocked(
	ctx context.Context,
	task domain.TaskSpec,
	budget int,
) (components, bool, error) {
	if ctx == nil {
		return components{}, false, errors.New("context is required")
	}
	if err := ctx.Err(); err != nil {
		return components{}, false, err
	}
	artifacts, err := r.dependencyArtifacts(task)
	if err != nil || len(artifacts) == 0 {
		return components{}, false, err
	}
	if budget <= 0 {
		return components{}, false, ErrTaskContextDisabled
	}
	required := false
	for _, artifact := range artifacts {
		required = required || !artifactDeliveredTo(artifact.record, task.AgentID)
	}
	if !required {
		return components{}, false, nil
	}
	candidate, err := r.cloneComponentsLocked()
	if err != nil {
		return components{}, false, r.poisonLocked(err)
	}
	current, err := candidate.registry.Get(task.WorkflowID, task.AgentID)
	if err != nil {
		return components{}, false, err
	}
	changed := false
	for _, artifact := range artifacts {
		// Durable delivery records outlive the evictable append replay ledger.
		// In particular, a producer sharing this Agent has already received its
		// original pinned reference; it must not be reappended with new flags.
		if artifactDeliveredTo(artifact.record, task.AgentID) {
			continue
		}
		if err := ctx.Err(); err != nil {
			return components{}, false, err
		}
		page, err := candidate.store.Lookup(artifact.record.PageID)
		if err != nil {
			return components{}, false, err
		}
		command := AppendCommand{
			TaskID: artifact.producerTaskID, WorkflowID: task.WorkflowID, AgentID: task.AgentID,
			ExpectedManifestID: current.ID,
			IdempotencyKey:     outputTargetKey(artifact.record.ID, task.AgentID),
			Content:            page.Content, Visibility: VisibilityWorkflow,
			Cold:            artifact.record.Cold,
			TaskTokenBudget: int64(budget), PrincipalPinnedBudget: int64(budget),
		}
		fingerprint, err := validateAppendCommand(command, r.config)
		if err != nil {
			return components{}, false, err
		}
		result, applied, err := applyAppendCandidate(&candidate, command, fingerprint, r.config)
		if errors.Is(err, errSequenceExhausted) {
			return components{}, false, r.poisonLocked(err)
		}
		if err != nil {
			return components{}, false, err
		}
		changed = changed || applied
		output := candidate.outputs[artifact.producerTaskID]
		stored := output.Artifacts[artifact.artifactIndex]
		if appendArtifactTarget(&stored, task.AgentID) {
			output.Artifacts[artifact.artifactIndex] = stored
			candidate.outputs[artifact.producerTaskID] = output
			changed = true
		}
		current, err = candidate.registry.Get(task.WorkflowID, task.AgentID)
		if err != nil || current.ID != result.ManifestID {
			return components{}, false, errors.Join(ErrInvalidCheckpoint, err)
		}
	}
	return candidate, changed, nil
}

func (r *Repository) dependencyArtifacts(task domain.TaskSpec) ([]dependencyArtifact, error) {
	result := make([]dependencyArtifact, 0)
	for _, dependencyID := range task.Dependencies {
		output, exists := r.outputs[dependencyID]
		if !exists {
			return nil, fmt.Errorf("%w: dependency %q", ErrOutputNotFound, dependencyID)
		}
		if output.WorkflowID != task.WorkflowID {
			return nil, ErrInvalidTaskBinding
		}
		for index, artifact := range output.Artifacts {
			if artifact.Visibility != VisibilityWorkflow || !artifactAllowsAgent(artifact, task.AgentID) {
				continue
			}
			result = append(result, dependencyArtifact{
				producerTaskID: output.TaskID, artifactIndex: index, record: artifact,
			})
		}
	}
	return result, nil
}

func artifactAllowsAgent(artifact ArtifactRecord, agentID string) bool {
	if artifact.Recipients == nil {
		return true
	}
	for _, recipient := range artifact.Recipients {
		if recipient == agentID {
			return true
		}
	}
	return false
}
