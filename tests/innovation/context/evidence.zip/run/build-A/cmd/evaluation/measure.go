package main

import (
	"context"
	"encoding/json"
	"os"
	"runtime"
	"sort"
	"sync"
	"time"
)

func runCommunicationTrial(ctx context.Context, dir string, c CommunicationCase, count, repetition int) (CommunicationTrial, error) {
	c.ReadPasses = 1
	if c.Operation == "context_load" {
		c.ReadPasses = 32
	}
	trial := CommunicationTrial{Case: c, Repetition: repetition, Samples: make([]CommunicationSample, count)}
	w, err := newCommunicationWorkload(ctx, dir, c, count)
	if err != nil {
		return trial, err
	}
	beforeFile, err := os.Stat(w.path)
	if err != nil {
		return trial, err
	}
	trial.CheckpointBeforeBytes = beforeFile.Size()
	trial.PhysicalBeforeBytes = w.repository.Stats().Store.PhysicalBytes
	saves, written := w.store.saves, w.store.written
	runtime.GC()
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	errors := make([]error, count)
	jobs := make(chan int, count)
	for i := 0; i < count; i++ {
		jobs <- i
	}
	close(jobs)
	start := make(chan struct{})
	var workers sync.WaitGroup
	for worker := 0; worker < c.Concurrency; worker++ {
		workers.Add(1)
		go func() {
			defer workers.Done()
			<-start
			for i := range jobs {
				began := time.Now()
				delivered, err := w.run(ctx, i)
				trial.Samples[i] = CommunicationSample{Index: i, LatencyNS: time.Since(began).Nanoseconds(), DeliveredBytes: delivered}
				errors[i] = err
			}
		}()
	}
	trial.StartedAt = time.Now().UTC()
	started := time.Now()
	close(start)
	workers.Wait()
	trial.WallNS = time.Since(started).Nanoseconds()
	runtime.ReadMemStats(&after)
	for _, err := range errors {
		if err != nil {
			return trial, err
		}
	}
	trial.TotalAllocBytes = after.TotalAlloc - before.TotalAlloc
	trial.HeapAllocBeforeBytes, trial.HeapAllocAfterBytes = before.HeapAlloc, after.HeapAlloc
	trial.Mallocs, trial.GCCycles = after.Mallocs-before.Mallocs, after.NumGC-before.NumGC
	afterFile, err := os.Stat(w.path)
	if err != nil {
		return trial, err
	}
	trial.CheckpointAfterBytes = afterFile.Size()
	trial.CheckpointSaveCalls = w.store.saves - saves
	trial.CheckpointPayloadWrittenBytes = w.store.written - written
	trial.PhysicalAfterBytes = w.repository.Stats().Store.PhysicalBytes
	latencies := make([]int64, count)
	for i, sample := range trial.Samples {
		latencies[i] = sample.LatencyNS
	}
	sort.Slice(latencies, func(i, j int) bool { return latencies[i] < latencies[j] })
	trial.P50NS, trial.P95NS = latencies[(count*50+99)/100-1], latencies[(count*95+99)/100-1]
	if err := w.verify(ctx, &trial); err != nil {
		return trial, err
	}
	// Correctness fields are measured independently by verify.
	return trial, nil
}

func writeCommunicationJSON(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(data, '\n'), 0o600)
}
