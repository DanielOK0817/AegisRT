package main

import "time"

type CommunicationCase struct {
	Operation    string `json:"operation"`
	PayloadBytes int    `json:"payload_bytes"`
	Recipients   int    `json:"recipients"`
	Concurrency  int    `json:"concurrency"`
	ReadPasses   int    `json:"read_passes"`
}

type CommunicationSample struct {
	Index          int   `json:"index"`
	LatencyNS      int64 `json:"latency_ns"`
	DeliveredBytes int   `json:"delivered_bytes"`
}

type CommunicationTrial struct {
	Case                          CommunicationCase     `json:"case"`
	Repetition                    int                   `json:"repetition"`
	StartedAt                     time.Time             `json:"started_at"`
	WallNS                        int64                 `json:"wall_ns"`
	Samples                       []CommunicationSample `json:"samples"`
	P50NS                         int64                 `json:"p50_ns"`
	P95NS                         int64                 `json:"p95_ns"`
	TotalAllocBytes               uint64                `json:"total_alloc_bytes"`
	HeapAllocBeforeBytes          uint64                `json:"heap_alloc_before_bytes"`
	HeapAllocAfterBytes           uint64                `json:"heap_alloc_after_bytes"`
	Mallocs                       uint64                `json:"mallocs"`
	GCCycles                      uint32                `json:"gc_cycles"`
	CheckpointBeforeBytes         int64                 `json:"checkpoint_before_bytes"`
	CheckpointAfterBytes          int64                 `json:"checkpoint_after_bytes"`
	CheckpointSaveCalls           uint64                `json:"checkpoint_save_calls"`
	CheckpointPayloadWrittenBytes uint64                `json:"checkpoint_payload_written_bytes"`
	PhysicalBeforeBytes           uint64                `json:"physical_before_bytes"`
	PhysicalAfterBytes            uint64                `json:"physical_after_bytes"`
	ReplayStable                  bool                  `json:"replay_stable"`
	ReloadVerified                bool                  `json:"reload_verified"`
	IsolationVerified             bool                  `json:"isolation_verified"`
}
