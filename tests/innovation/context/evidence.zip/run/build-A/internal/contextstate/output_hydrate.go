package contextstate

import (
	"context"
	"errors"
	"fmt"

	"aegisrt/internal/domain"
)

type dependencyArtifact struct {
	producerTaskID string
	artifactIndex  int
	record         ArtifactRecord
}

func (r *Repository) hydrateDependenciesLocked(
	ctx context.Context,
	task domain.TaskSpec,
	budget int,
) (components, bool, error) {
	if ctx == nil {
		return components{}, false, errors.New("context is required")
	}
	if err := ctx.Err(); err != nil {
		return components{}, false, err
	}
	artifacts, err := r.dependencyArtifacts(task)
	if err != nil || len(artifacts) == 0 {
		return components{}, false, err
	}
	if budget <= 0 {
		return components{}, false, ErrTaskContextDisabled
	}
	required, err := r.hydrationRequiredLocked(task, budget, artifacts)
	if err != nil || !required {
		return components{}, false, err
	}
	candidate, err := r.cloneComponentsLocked()
	if err != nil {
		return components{}, false, r.poisonLocked(err)
	}
	current, err := candidate.registry.Get(task.WorkflowID, task.AgentID)
	if err != nil {
		return components{}, false, err
	}
	changed := false
	for _, artifact := range artifacts {
		if err := ctx.Err(); err != nil {
			return components{}, false, err
		}
		page, err := candidate.store.Lookup(artifact.record.PageID)
		if err != nil {
			return components{}, false, err
		}
		command := AppendCommand{
			TaskID: artifact.producerTaskID, WorkflowID: task.WorkflowID, AgentID: task.AgentID,
			ExpectedManifestID: current.ID,
			IdempotencyKey:     outputTargetKey(artifact.record.ID, task.AgentID),
			Content:            page.Content, Visibility: VisibilityWorkflow,
			Cold:            artifact.record.Cold,
			TaskTokenBudget: int64(budget), PrincipalPinnedBudget: int64(budget),
		}
		fingerprint, err := validateAppendCommand(command, r.config)
		if err != nil {
			return components{}, false, err
		}
		result, applied, err := applyAppendCandidate(&candidate, command, fingerprint, r.config)
		if errors.Is(err, errSequenceExhausted) {
			return components{}, false, r.poisonLocked(err)
		}
		if err != nil {
			return components{}, false, err
		}
		changed = changed || applied
		output := candidate.outputs[artifact.producerTaskID]
		stored := output.Artifacts[artifact.artifactIndex]
		if appendArtifactTarget(&stored, task.AgentID) {
			output.Artifacts[artifact.artifactIndex] = stored
			candidate.outputs[artifact.producerTaskID] = output
			changed = true
		}
		current, err = candidate.registry.Get(task.WorkflowID, task.AgentID)
		if err != nil || current.ID != result.ManifestID {
			return components{}, false, errors.Join(ErrInvalidCheckpoint, err)
		}
	}
	return candidate, changed, nil
}

func (r *Repository) dependencyArtifacts(task domain.TaskSpec) ([]dependencyArtifact, error) {
	result := make([]dependencyArtifact, 0)
	for _, dependencyID := range task.Dependencies {
		output, exists := r.outputs[dependencyID]
		if !exists {
			return nil, fmt.Errorf("%w: dependency %q", ErrOutputNotFound, dependencyID)
		}
		if output.WorkflowID != task.WorkflowID {
			return nil, ErrInvalidTaskBinding
		}
		for index, artifact := range output.Artifacts {
			if artifact.Visibility != VisibilityWorkflow || !artifactAllowsAgent(artifact, task.AgentID) {
				continue
			}
			result = append(result, dependencyArtifact{
				producerTaskID: output.TaskID, artifactIndex: index, record: artifact,
			})
		}
	}
	return result, nil
}

func (r *Repository) hydrationRequiredLocked(
	task domain.TaskSpec,
	budget int,
	artifacts []dependencyArtifact,
) (bool, error) {
	current, err := r.registry.Get(task.WorkflowID, task.AgentID)
	if err != nil {
		return false, err
	}
	for _, artifact := range artifacts {
		page, err := r.store.Lookup(artifact.record.PageID)
		if err != nil {
			return false, err
		}
		command := hydrationAppendCommand(task, budget, current.ID, artifact, page.Content)
		fingerprint, err := validateAppendCommand(command, r.config)
		if err != nil {
			return false, err
		}
		record, exists := r.ledger[ledgerKey{taskID: command.TaskID, key: command.IdempotencyKey}]
		if !exists || !artifactDeliveredTo(artifact.record, task.AgentID) {
			return true, nil
		}
		if record.Fingerprint != fingerprint {
			return false, ErrIdempotencyConflict
		}
	}
	return false, nil
}

func hydrationAppendCommand(
	task domain.TaskSpec,
	budget int,
	manifestID string,
	artifact dependencyArtifact,
	content string,
) AppendCommand {
	return AppendCommand{
		TaskID: artifact.producerTaskID, WorkflowID: task.WorkflowID, AgentID: task.AgentID,
		ExpectedManifestID: manifestID,
		IdempotencyKey:     outputTargetKey(artifact.record.ID, task.AgentID),
		Content:            content, Visibility: VisibilityWorkflow,
		Cold:                  artifact.record.Cold,
		TaskTokenBudget:       int64(budget),
		PrincipalPinnedBudget: int64(budget),
	}
}

func artifactAllowsAgent(artifact ArtifactRecord, agentID string) bool {
	if artifact.Recipients == nil {
		return true
	}
	for _, recipient := range artifact.Recipients {
		if recipient == agentID {
			return true
		}
	}
	return false
}
